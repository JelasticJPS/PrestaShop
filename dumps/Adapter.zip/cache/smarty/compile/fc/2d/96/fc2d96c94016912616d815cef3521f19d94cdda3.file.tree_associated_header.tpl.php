<?php /* Smarty version Smarty-3.1.19, created on 2015-08-22 14:56:38
         compiled from "/var/www/webroot/ROOT/prestashop/admin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:215843055d88da6074925-49948976%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fc2d96c94016912616d815cef3521f19d94cdda3' => 
    array (
      0 => '/var/www/webroot/ROOT/prestashop/admin/themes/default/template/controllers/products/helpers/tree/tree_associated_header.tpl',
      1 => 1440063812,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '215843055d88da6074925-49948976',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'toolbar' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55d88da60f5162_02815663',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55d88da60f5162_02815663')) {function content_55d88da60f5162_02815663($_smarty_tpl) {?>
<div class="tree-panel-heading-controls clearfix"><?php if (isset($_smarty_tpl->tpl_vars['toolbar']->value)) {?><?php echo $_smarty_tpl->tpl_vars['toolbar']->value;?>
<?php }?></div>
<?php }} ?>
