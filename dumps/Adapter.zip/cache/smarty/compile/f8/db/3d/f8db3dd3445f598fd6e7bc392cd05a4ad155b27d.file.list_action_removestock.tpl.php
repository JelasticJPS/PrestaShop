<?php /* Smarty version Smarty-3.1.19, created on 2015-08-22 14:56:59
         compiled from "/var/www/webroot/ROOT/prestashop/admin/themes/default/template/helpers/list/list_action_removestock.tpl" */ ?>
<?php /*%%SmartyHeaderCode:86029620555d88dbb8fc0d4-83081234%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f8db3dd3445f598fd6e7bc392cd05a4ad155b27d' => 
    array (
      0 => '/var/www/webroot/ROOT/prestashop/admin/themes/default/template/helpers/list/list_action_removestock.tpl',
      1 => 1440063812,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '86029620555d88dbb8fc0d4-83081234',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'href' => 0,
    'action' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55d88dbb952b60_61096624',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55d88dbb952b60_61096624')) {function content_55d88dbb952b60_61096624($_smarty_tpl) {?>
<a href="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['href']->value, ENT_QUOTES, 'UTF-8', true);?>
" title="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['action']->value, ENT_QUOTES, 'UTF-8', true);?>
">
	<i class="icon-circle-arrow-down"></i> <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['action']->value, ENT_QUOTES, 'UTF-8', true);?>

</a>
<?php }} ?>
