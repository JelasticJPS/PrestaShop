<?php /* Smarty version Smarty-3.1.19, created on 2015-08-22 14:56:34
         compiled from "/var/www/webroot/ROOT/prestashop/admin/themes/default/template/controllers/login/layout.tpl" */ ?>
<?php /*%%SmartyHeaderCode:184183396455d88da2156ff1-64112330%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4064b8d7130accf434a10c66582eab430474495e' => 
    array (
      0 => '/var/www/webroot/ROOT/prestashop/admin/themes/default/template/controllers/login/layout.tpl',
      1 => 1440063812,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '184183396455d88da2156ff1-64112330',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'header' => 0,
    'page' => 0,
    'footer' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_55d88da215d422_39906872',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_55d88da215d422_39906872')) {function content_55d88da215d422_39906872($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['header']->value;?>

<?php echo $_smarty_tpl->tpl_vars['page']->value;?>

<?php echo $_smarty_tpl->tpl_vars['footer']->value;?>
<?php }} ?>
